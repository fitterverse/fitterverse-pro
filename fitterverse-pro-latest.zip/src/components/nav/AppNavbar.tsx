import React from "react";
import { Link, NavLink, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/state/authStore";

// Small helper for active link styles
const linkCls = (isActive: boolean) =>
  "px-3 py-2 rounded-lg transition " +
  (isActive ? "text-teal-300" : "text-slate-300 hover:text-white");

export default function AppNavbar() {
  const { user, signOut } = useAuth();
  const [menuOpen, setMenuOpen] = React.useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // Close menu on route change
  React.useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur border-b border-slate-800">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 md:px-10 h-14 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to={user ? "/dashboard" : "/"} className="font-bold text-lg">
            Fitterverse
          </Link>
          {user && (
            <NavLink to="/dashboard" className={({ isActive }) => linkCls(isActive)}>
              Dashboard
            </NavLink>
          )}
        </div>

        {/* Right actions */}
        <div className="relative">
          <button
            aria-label="Menu"
            onClick={() => setMenuOpen((v) => !v)}
            className="inline-flex items-center justify-center h-10 w-10 rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700"
          >
            <span className="text-lg">≡</span>
          </button>

          {menuOpen && (
            <div className="absolute right-0 mt-2 w-48 rounded-xl border border-slate-800 bg-slate-900/90 shadow-lg p-2">
              {/* Add habit from menu */}
              {user && (
                <button
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 text-slate-100"
                  onClick={() => navigate("/onboarding?mode=add")}
                >
                  + Add habit
                </button>
              )}

              <button
                className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 text-slate-100"
                onClick={() => navigate("/settings")}
              >
                Settings
              </button>

              {user ? (
                <button
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 text-rose-300"
                  onClick={signOut}
                >
                  Logout
                </button>
              ) : (
                <button
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 text-slate-100"
                  onClick={() => (window as any)._openAuth?.()}
                >
                  Sign in
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
