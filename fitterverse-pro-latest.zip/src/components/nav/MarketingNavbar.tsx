// src/components/nav/MarketingNavbar.tsx
import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Button from "@/components/ui/Button";
import { useAuth } from "@/state/authStore";

export default function MarketingNavbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const isActive = (p: string) => pathname === p;

  return (
    <nav className="sticky top-0 z-40 bg-slate-950/70 backdrop-blur border-b border-slate-800">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 md:px-10 h-14 flex items-center justify-between">
        <Link to="/" className="font-bold text-white text-lg">
          Fitterverse
        </Link>

        {!user ? (
          // Logged OUT — classic marketing nav
          <div className="hidden sm:flex items-center gap-4">
            <Link to="/blog" className={`text-sm ${isActive("/blog") ? "text-teal-400" : "text-slate-300 hover:text-white"}`}>
              Blog
            </Link>
            <Link to="/pricing" className={`text-sm ${isActive("/pricing") ? "text-teal-400" : "text-slate-300 hover:text-white"}`}>
              Pricing
            </Link>
            <Link to="/about" className={`text-sm ${isActive("/about") ? "text-teal-400" : "text-slate-300 hover:text-white"}`}>
              About
            </Link>
            <Button onClick={() => (window as any)._openAuth?.()} className="bg-teal-500 hover:bg-teal-400 text-black">
              Start for free
            </Button>
          </div>
        ) : (
          // Logged IN — app nav
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={() => navigate("/dashboard")}>Dashboard</Button>
            <Button
              className="bg-teal-500 hover:bg-teal-400 text-black"
              onClick={() => navigate("/onboarding?mode=add")}
            >
              + Add habit
            </Button>

            <div className="relative group">
              <button className="px-3 py-2 rounded-xl border border-slate-800 bg-slate-900/60">
                ☰
              </button>
              <div className="absolute right-0 mt-2 w-44 rounded-xl border border-slate-800 bg-slate-900/95 shadow-lg p-2 hidden group-hover:block">
                <button
                  onClick={() => navigate("/settings")}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800"
                >
                  Settings
                </button>
                <button
                  onClick={logout}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 text-red-300"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
