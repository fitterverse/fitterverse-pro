// src/pages/Dashboard.tsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  collection,
  onSnapshot,
  query,
  where,
  orderBy,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/state/authStore";
import Card from "@/components/ui/Card";

type UserHabit = {
  id: string;
  uid: string;
  name: string;
  type: string;
  createdAt?: any;
};

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [habits, setHabits] = useState<UserHabit[]>([]);
  const [loading, setLoading] = useState(true);
  const [indexNeeded, setIndexNeeded] = useState<string | null>(null);

  useEffect(() => {
    if (!user) navigate("/", { replace: true });
  }, [user, navigate]);

  useEffect(() => {
    if (!user) return;

    // Query: uid + createdAt desc (needs composite index)
    const q = query(
      collection(db, "user_habits"),
      where("uid", "==", user.uid),
      orderBy("createdAt", "desc")
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const rows: UserHabit[] = [];
        snap.forEach((d) => rows.push({ id: d.id, ...(d.data() as any) }));
        setHabits(rows);
        setIndexNeeded(null);
        setLoading(false);
      },
      (err: any) => {
        // If Firestore emits an index build link, expose it to the UI.
        const msg: string = String(err?.message || "");
        if (msg.includes("create_composite=")) {
          setIndexNeeded(msg);
        }
        setLoading(false);
      }
    );

    return () => unsub();
  }, [user]);

  if (!user) return null;

  const handleAddHabit = () => navigate("/onboarding?mode=add");

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <section className="max-w-6xl mx-auto px-4 sm:px-6 md:px-10 py-8 md:py-10">
        <h1 className="text-2xl md:text-3xl font-bold">
          Your habits{user.displayName ? `, ${user.displayName}` : ""}
        </h1>
        <p className="mt-2 text-slate-300">
          Tap a habit to view progress, streaks, and reviews.
        </p>

        <div className="grid md:grid-cols-3 gap-4 mt-6">
          {loading && (
            <Card className="bg-slate-900/60 border-slate-800 p-5 md:col-span-3">
              Loading your habits…
            </Card>
          )}

          {!loading && indexNeeded && (
            <Card className="bg-slate-900/60 border-slate-800 p-5 md:col-span-3">
              <h3 className="font-semibold">Couldn’t load habits</h3>
              <p className="text-slate-300 mt-2 text-sm break-all">
                The query requires an index. You can create it here:{" "}
                {indexNeeded}
              </p>
            </Card>
          )}

          {!loading && !indexNeeded && habits.length === 0 && (
            <Card className="bg-slate-900/60 border-slate-800 p-5 md:col-span-3">
              <h3 className="font-semibold">No habits yet</h3>
              <p className="text-slate-300 mt-1 text-sm">
                Use “Add habit” to create your first one.
              </p>
            </Card>
          )}

          {!indexNeeded &&
            habits.map((h) => (
              <Card
                key={h.id}
                className="bg-slate-900/60 border-slate-800 p-5 hover:border-slate-700 cursor-pointer"
                onClick={() => navigate(`/habit/${h.id}`)}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold">{h.name}</h3>
                    <p className="text-slate-400 text-sm mt-1">
                      Type: {h.type.replace(/_/g, " ")}
                    </p>
                  </div>
                  <span className="text-xs text-slate-400">View</span>
                </div>
              </Card>
            ))}
        </div>
      </section>

      {/* Floating action button (keep this) */}
      <button
        onClick={handleAddHabit}
        className="fixed right-4 bottom-20 sm:right-6 sm:bottom-6 rounded-full bg-teal-500 hover:bg-teal-400 text-black px-6 py-4 text-lg font-semibold shadow-lg"
      >
        + Add habit
      </button>
    </div>
  );
}
